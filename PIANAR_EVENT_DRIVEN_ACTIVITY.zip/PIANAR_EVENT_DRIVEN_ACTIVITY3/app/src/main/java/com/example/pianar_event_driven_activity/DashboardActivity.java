package com.example.pianar_event_driven_activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        Button btnCustomer = findViewById(R.id.btnCustomer);
        Button btnUserList = findViewById(R.id.btnUserList);
        Button btnLogout = findViewById(R.id.btnLogout);

        // "Welcome, <first name>!" (falls back to email, then "User")
        String firstName = getIntent().getStringExtra("firstName");
        String email = getIntent().getStringExtra("email");
        String name = !TextUtils.isEmpty(firstName) ? firstName
                : (!TextUtils.isEmpty(email) ? email : "User");
        tvWelcome.setText("Welcome, " + name + "!");

        // Customer button -> Customer screen (Supabase list)
        btnCustomer.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, CustomerActivity.class)));

        // User List button -> All Registered Users screen
        btnUserList.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, UsersActivity.class)));

        // Logout -> fresh login page
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
